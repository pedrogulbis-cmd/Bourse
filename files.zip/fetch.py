"""
Récupère les fondamentaux d'un titre via yfinance (qui gère nativement
l'authentification cookie+crumb de Yahoo — c'est tout l'intérêt de passer
par une lib Python plutôt que par le navigateur).

Champs produits (mêmes noms logiques que côté web, dans app.js) :
  price, mcap, pb, pe, ps, pcf, ebitda_yield, div_yield, buyback_yield,
  mom3, mom6, eps_growth
"""
import math
import yfinance as yf


def _row_lookup(df, candidates_substrings):
    """Cherche dans l'index d'un DataFrame yfinance une ligne dont le libellé
    contient l'une des sous-chaînes données (insensible à la casse/espaces)."""
    if df is None or df.empty:
        return None
    norm_index = {str(i).lower().replace(" ", ""): i for i in df.index}
    for cand in candidates_substrings:
        key = cand.lower().replace(" ", "")
        for norm, original in norm_index.items():
            if key in norm:
                return original
    return None


def _safe_float(v):
    try:
        f = float(v)
        if math.isnan(f) or math.isinf(f):
            return None
        return f
    except (TypeError, ValueError):
        return None


def _positive_or_none(v):
    v = _safe_float(v)
    return v if (v is not None and v > 0) else None


def fetch_symbol(symbol):
    """Retourne (data_dict, error_message). data_dict est toujours un dict
    (potentiellement rempli de None) ; error_message est None en cas de succès."""
    data = {
        "price": None, "mcap": None, "pb": None, "pe": None, "ps": None,
        "pcf": None, "ebitda_yield": None, "div_yield": None,
        "buyback_yield": None, "mom3": None, "mom6": None, "eps_growth": None,
    }
    try:
        t = yf.Ticker(symbol)

        # --- valorisation (P/E, P/B, P/S, EV/EBITDA, market cap) en un seul appel ---
        val = t.get_valuation_measures(periods=0)  # colonne "Current" uniquement
        if val is not None and not val.empty and "Current" in val.columns:
            def vget(label):
                return val.loc[label, "Current"] if label in val.index else None
            mcap = _safe_float(vget("Market Cap"))
            pe = _positive_or_none(vget("Trailing P/E"))
            pb = _positive_or_none(vget("Price/Book"))
            ps = _positive_or_none(vget("Price/Sales"))
            ev_ebitda = _positive_or_none(vget("Enterprise Value/EBITDA"))
            data["mcap"] = mcap
            data["pe"] = pe
            data["pb"] = pb
            data["ps"] = ps
            data["ebitda_yield"] = (1.0 / ev_ebitda) if ev_ebitda else None

        # --- dividende + prix courant (info reste utile pour ces deux-là) ---
        info = {}
        try:
            info = t.info or {}
        except Exception:
            info = {}
        data["price"] = _safe_float(info.get("currentPrice") or info.get("regularMarketPrice"))
        div_yield = _safe_float(info.get("dividendYield"))
        if div_yield is not None and div_yield > 1:
            div_yield = div_yield / 100.0  # certaines versions renvoient déjà un %, pas une fraction
        if div_yield is not None and div_yield > 0.25:
            # Rendement du dividende TTM > 25% : quasi toujours une donnée aberrante
            # (dividende exceptionnel ponctuel confondu avec le régulier, erreur de
            # source, etc.) plutôt qu'un vrai rendement soutenable — on l'écarte
            # plutôt que de laisser un seul titre fausser tout le classement.
            div_yield = None
        data["div_yield"] = div_yield or 0.0
        if not data["mcap"]:
            data["mcap"] = _safe_float(info.get("marketCap"))
        if not data["price"]:
            data["price"] = _safe_float(info.get("previousClose"))

        # --- P/CF : approximé via cash flow opérationnel / capitalisation ---
        try:
            cf = t.cash_flow
            ocf_row = _row_lookup(cf, ["Operating Cash Flow", "Total Cash From Operating Activities"])
            if ocf_row is not None and data["mcap"]:
                ocf = _safe_float(cf.loc[ocf_row].iloc[0])
                if ocf and ocf > 0:
                    data["pcf"] = data["mcap"] / ocf

            buyback_row = _row_lookup(cf, ["Repurchase Of Capital Stock", "Repurchase Of Stock", "CommonStockRepurchased"])
            if buyback_row is not None and data["mcap"]:
                buyback = _safe_float(cf.loc[buyback_row].iloc[0])  # négatif = cash dépensé
                if buyback is not None:
                    by = max(0.0, -buyback) / data["mcap"]
                    data["buyback_yield"] = by if by <= 0.30 else None  # >30% = donnée aberrante, écartée
        except Exception:
            pass

        # --- croissance : variation du résultat net (proxy de la croissance des bénéfices) ---
        try:
            inc = t.income_stmt
            ni_row = _row_lookup(inc, ["Net Income"])
            if ni_row is not None and inc.shape[1] >= 2:
                latest = _safe_float(inc.loc[ni_row].iloc[0])
                prior = _safe_float(inc.loc[ni_row].iloc[1])
                if latest is not None and prior:
                    data["eps_growth"] = (latest - prior) / abs(prior)
        except Exception:
            pass

        # --- momentum 3 / 6 mois depuis l'historique de prix ---
        try:
            hist = t.history(period="7mo", interval="1d", auto_adjust=True)
            closes = hist["Close"].dropna()
            if len(closes) > 5:
                last = closes.iloc[-1]
                idx3 = max(0, len(closes) - 64)
                idx6 = max(0, len(closes) - 127)
                c3, c6 = closes.iloc[idx3], closes.iloc[idx6]
                if c3:
                    data["mom3"] = ((last / c3) - 1) * 100
                if c6:
                    data["mom6"] = ((last / c6) - 1) * 100
        except Exception:
            pass

        # rendement actionnarial = dividende + rachats (calculé côté export, pas ici,
        # pour rester cohérent avec le format stocké — voir export.py)

        if data["price"] is None and data["mcap"] is None and data["pe"] is None:
            return data, "aucune donnée renvoyée (titre inconnu ou marché non couvert)"
        return data, None

    except Exception as e:
        return data, str(e)
