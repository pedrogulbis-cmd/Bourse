# Scraper Trending Value — génération du snapshot local

Récupère l'univers réel des grands indices (S&P 500, CAC 40, DAX, FTSE 100,
Nikkei 225, SMI, AEX, S&P/TSX 60) depuis Wikipedia, puis les fondamentaux de
chaque titre via `yfinance` (qui gère nativement l'authentification Yahoo —
cookie + crumb — impossible à reproduire depuis un navigateur). Stocke tout
dans une base SQLite locale, puis exporte `data-snapshot.json` à la racine
du site pour que `index.html` le lise directement, sans appel réseau ni clé
API pour les visiteurs du site.

## Installation (une fois)

```bash
cd scraper
python3 -m venv venv
source venv/bin/activate        # Windows : venv\Scripts\activate
pip install -r requirements.txt
```

## Premier run — test rapide sur un petit échantillon

Avant de lancer une récupération complète (peut prendre 15-40 minutes selon
le nombre de titres), teste sur un tout petit échantillon :

```bash
python run.py --countries US --limit 15
```

Vérifie que `../data-snapshot.json` a bien été créé et contient des données
qui ont du sens (`cat ../data-snapshot.json | head -c 2000`).

## Run complet

```bash
python run.py
```

Récupère tous les pays configurés dans `config.py`, avec une pause polie
(~0,6 à 1,4s) entre chaque titre pour ne pas se faire bloquer par Yahoo.
Pour ~1000 titres (tous indices confondus), compte 15-40 minutes.

## Runs suivants (mise à jour)

```bash
python run.py --max-age-days 7
```

Ne re-télécharge que les titres dont les données ont plus de 7 jours (ou
qui n'ont jamais été récupérés avec succès) — beaucoup plus rapide qu'un
run complet. Réduis `--max-age-days` si tu veux des données plus fraîches,
augmente-le pour aller plus vite.

Pour ne pas re-taper Wikipedia à chaque fois (l'univers change rarement) :

```bash
python run.py --skip-universe --max-age-days 3
```

## Déploiement

Une fois `data-snapshot.json` généré :

```bash
cd ..   # retour à la racine du site
git add data-snapshot.json
git commit -m "Mise à jour du snapshot de données"
git push
```

Le site lit ce fichier automatiquement (mode "Snapshot local", sélectionné
par défaut) — pas besoin de toucher au code du site pour une mise à jour de
données.

## Automatiser (optionnel)

Sur macOS/Linux, une tâche cron hebdomadaire :

```cron
0 8 * * 1 cd /chemin/vers/scraper && venv/bin/python run.py --max-age-days 7 && cd .. && git add data-snapshot.json && git commit -m "Snapshot auto" && git push
```

Sur Windows, le Planificateur de tâches avec un script `.bat` équivalent.

## Fichiers

- `config.py` — indices sources, suffixes de ticker, réglages de délai
- `db.py` — schéma SQLite et requêtes (univers + fondamentaux)
- `universe.py` — parsing des tableaux Wikipedia (`pandas.read_html`)
- `fetch.py` — récupération par titre via `yfinance` (valorisation, dividende,
  rachats d'actions, momentum 3/6 mois, croissance du résultat net)
- `export.py` — dump SQLite → `data-snapshot.json`
- `run.py` — orchestrateur CLI (voir `python run.py --help`)

## Limites connues

- **Rendement actionnarial** : les rachats d'actions viennent du cash-flow
  statement le plus récent (généralement annuel chez yfinance sur le plan
  gratuit), pas d'un TTM glissant exact.
- **Croissance des bénéfices** : approximée par la variation du résultat net
  (Net Income) d'une année sur l'autre, faute d'un accès simple à l'EPS
  historique fiable pour tous les marchés. C'est un proxy raisonnable, pas
  une reproduction exacte de la définition du livre.
- **Scraping Yahoo Finance** : techniquement contraire à leurs conditions
  d'utilisation au-delà d'un usage personnel non commercial. Ce projet est
  un outil personnel de screening, pas un produit redistribuant les données.
- **Fiabilité de `yfinance`** : Yahoo modifie parfois son API sans préavis,
  ce qui peut casser `yfinance` temporairement (voir leur dépôt GitHub pour
  les incidents en cours). En cas d'échecs massifs soudains, vérifier
  `pip install --upgrade yfinance`.
