# Le Grand Livre — Screener Wall Street

Screener boursier en HTML/JS pur (comme AR/SAR Tracker et Card Scout), qui reproduit fidèlement
6 stratégies quantitatives décrites dans *What Works on Wall Street* (J. O'Shaughnessy, 4e éd.) :

| Stratégie | Idée | Perf. annoncée dans le livre |
|---|---|---|
| **Trending Value** | Value Composite Two (6 ratios) décile 1 + top momentum 6 mois | 21,2 %/an (1964–2009) |
| **Value Composite Two** | Value Composite Two seul, sans momentum | 17,3 %/an |
| **Cheap Stocks on the Mend** | Top 30% value + momentum 3&6 mois > médiane | 19,8 %/an |
| **All Stocks Growth** | Croissance EPS>0 + momentum + qualité value médiane | 20,5 %/an |
| **Shareholder Yield** | Dividende + rachats d'actions, décile 1 | 14,9 %/an (1927–2009) |
| **Market Leaders + Yield + Momentum** | Grandes caps + momentum + rendement actionnarial | ≈17,9 %/an |

Toutes les définitions de facteurs, seuils de décile et règles de sélection sont dans `data.js`
(objet `STRATEGIES`), directement traduites des chapitres 15, 25, 26 et 27 du livre.

## v2.0 — Architecture hybride (recommandée)

Le site lit par défaut `data-snapshot.json`, un fichier généré **localement** par le scraper
Python du dossier `scraper/` (voir `scraper/README.md`). C'est la source la plus fiable :

- **Univers complet**, pas un échantillon limité par un quota API (S&P 500 entier, CAC 40
  entier, etc.)
- **Aucune clé, aucun quota, aucun CORS** pour les visiteurs du site — le JSON est un fichier
  statique comme n'importe quel autre fichier du repo
- **International qui fonctionne vraiment** : le scraper tourne côté serveur (ton PC), donc
  `yfinance` peut gérer l'authentification Yahoo (cookie + crumb) correctement — chose
  impossible depuis un navigateur, ce qui bloquait FMP/Finnhub gratuits sur les marchés hors USA

Workflow : lance le scraper une fois par semaine (ou via une tâche planifiée), commit le
`data-snapshot.json` généré, push — le site se met à jour automatiquement.

Les modes **FMP** et **Finnhub** (API en direct, décrits ci-dessous) restent disponibles dans
les réglages avancés pour un coup d'œil ponctuel entre deux exécutions du scraper, mais ne sont
plus le chemin recommandé.

## Pourquoi cette architecture (important à comprendre)

Le plan **gratuit** de Financial Modeling Prep (la source de données fondamentales) bloque
le screener et la liste globale de titres ("Restricted Endpoint"). En revanche, les endpoints
**par titre individuel** (`quote`, `ratios-ttm`, `key-metrics-ttm`, `stock-price-change`,
`cash-flow-statement-ttm`) fonctionnent très bien sur ce plan.

Donc, plutôt que d'écrire une liste de tickers à la main (ce qui n'aurait aucune légitimité —
impossible de "connaître" tout un marché soi-même), l'univers de titres est **récupéré
dynamiquement depuis Wikipedia** : la vraie composition actuelle du S&P 500, du CAC 40, du DAX,
du FTSE 100, du Nikkei 225, du SMI, de l'AEX et du S&P/TSX 60 (`data.js`, objet `INDEX_SOURCES`).
L'API Wikipedia autorise les requêtes cross-origin (`origin=*`) directement depuis le navigateur,
sans backend ni clé.

Contrainte : le quota gratuit FMP est de 250 requêtes/jour, soit ~50 titres analysables par
run (5 appels/titre). On ne peut donc pas passer tout un indice de 500 titres dans une seule
requête. Le screener prend à chaque lancement un **échantillon réel** de l'indice, en
priorisant les titres jamais encore analysés (ou les plus anciens en cache) — au fil des
sessions, la couverture s'élargit et se rafraîchit automatiquement, sans jamais dépasser le quota.

## Deux sources de données (bascule dans les réglages)

- **Financial Modeling Prep** (par défaut) : nécessite une clé gratuite, 250 requêtes/jour.
  Endpoints par titre uniquement (voir plus haut).
- **Finnhub (secours gratuit)** : nécessite une clé gratuite distincte (finnhub.io/register),
  60 requêtes/minute — bien plus généreux que FMP. Contrairement à Yahoo Finance (essayé
  initialement, abandonné — voir note ci-dessous), Finnhub gère nativement le CORS et
  fonctionne en appel direct depuis le navigateur, sans proxy.
  - 2 appels par titre : `/stock/metric?metric=all` (P/E, P/B, P/S, EV/EBITDA, dividende,
    momentum 3/6 mois — tout dans une seule requête) + `/quote` (prix courant).
  - **Couverture confirmée limitée aux bourses américaines sur le plan gratuit** — les
    marchés internationaux (`.PA`, `.DE`, `.T`...) renvoient une erreur d'accès explicite
    ("You don't have access to this resource"), pas un simple manque de données. Testé et
    confirmé en conditions réelles (LVMH `MC.PA`). Pour l'international, reste sur FMP — dont
    la couverture par titre individuel hors USA n'a pas encore été confirmée en conditions
    réelles (quota épuisé au moment des premiers tests) ; à vérifier dès qu'un quota FMP frais
    est disponible, avec par exemple `ratios-ttm?symbol=MC.PA`.
  - Limite connue : pas de champ fiable pour les rachats d'actions sur l'accès gratuit, donc
    le rendement actionnarial se limite au dividende sur cette source (contre dividende +
    rachats sur FMP).
  - Les deux sources ont leur propre cache 24h (clés `fmp:SYMBOL` / `finnhub:SYMBOL`), donc
    basculer de l'une à l'autre ne mélange jamais leurs données.

**Pourquoi pas Yahoo Finance ?** Une première version utilisait Yahoo Finance via un proxy
CORS public. Yahoo a fermé son accès non-authentifié mi-2023 (système de "crumb" + cookie de
session anti-scraping) — même `yfinance` (Python) doit gérer cette mécanique, qui est
structurellement impossible à reproduire de façon fiable depuis un navigateur sans backend
dédié (les cookies ne survivent pas au passage par un proxy tiers). Cette source a donc été
retirée au profit de Finnhub, qui fonctionne réellement.

## Mise en route

1. Crée un compte gratuit sur [financialmodelingprep.com](https://site.financialmodelingprep.com/developer/docs/dashboard)
   → récupère ta clé API (250 requêtes/jour gratuites).
2. Ouvre `index.html` (en local ou une fois déployé), colle ta clé dans le panneau
   "Clé API & réglages avancés". Elle reste uniquement dans le `localStorage` de ton navigateur.
3. Choisis une stratégie, une zone/des pays, ajuste la taille de l'échantillon par pays
   (le compteur de requêtes API s'actualise en direct — reste sous 250/jour).
4. Clique "Lancer le screening".

## Déploiement GitHub Pages

```bash
git init
git add index.html app.js data.js README.md
git commit -m "Screener Wall Street v1"
git branch -M main
git remote add origin https://github.com/<ton-user>/<repo>.git
git push -u origin main
```

Puis Settings → Pages → Deploy from branch → `main` / `root`. Vérifie bien que `index.html`
est **à la racine** (pas de suffixe type `index-1.html`, pas de sous-dossier).

## Comment ça marche techniquement

- **Univers** : pour chaque pays sélectionné, une requête Wikipedia (mise en cache 30 jours,
  la composition d'un indice change rarement) fournit la liste réelle des titres de l'indice
  de référence de ce pays, avec parsing automatique du tableau (détection de colonnes par
  mots-clés, pas d'indices codés en dur) et ajout du suffixe de place de marché FMP
  (`.TO` Canada, `.T` Japon, `.L` Royaume-Uni, `.PA` France, `.DE` Allemagne, `.SW` Suisse,
  `.AS` Pays-Bas).
- **Échantillonnage** : parmi cet univers réel, on tire les N titres (réglage "Échantillon
  analysé / pays") jamais encore récupérés en priorité — voir ci-dessus.
- **Fondamentaux** : pour chaque candidat, 5 appels FMP par titre sont récupérés puis
  **mis en cache 24h** dans le navigateur — changer de stratégie ou de nombre de résultats
  ne relance pas d'appels si les données sont déjà en cache.
- **Scoring** : chaque facteur (P/B, P/E, P/S, EBITDA/EV, P/CF, rendement actionnarial) est
  converti en rang percentile 1-100 sur l'échantillon récupéré, exactement comme dans le livre
  (valeur manquante → rang neutre 50). Les rangs sont sommés pour former le score composite
  Value Composite Two, puis chaque stratégie applique ses propres filtres/tri sur ce score
  et sur le momentum 3/6 mois.

## Limites connues (honnêtes)

- **Échantillon, pas indice complet à chaque run** : avec un quota gratuit de 250 requêtes/jour,
  on ne peut pas recalculer les rangs sur l'intégralité d'un indice de 500 titres en une fois.
  Le classement est donc relatif à l'échantillon effectivement récupéré (affiché sous
  "Échantillon analysé : X / Y titres de l'univers réel"), pas à l'indice entier — mais cet
  univers de référence, lui, est bien réel et à jour (Wikipedia), pas une liste inventée.
- **Couverture hors USA sur FMP** : les endpoints par titre semblent fonctionner pour les titres
  US sur le plan gratuit ; le comportement pour les tickers internationaux (`.PA`, `.DE`, `.T`...)
  n'a pas encore été vérifié en conditions réelles — teste et signale si certains pays renvoient
  beaucoup de rangs neutres (50 partout), signe de données manquantes.
- **Format des tickers internationaux** : les suffixes (`.PA`, `.DE`, `.T`...) suivent la
  convention standard (identique à Yahoo Finance), mais si FMP utilise un format différent pour
  un pays donné, ce pays renverra des erreurs "symbole introuvable" — à ajuster dans
  `INDEX_SOURCES` (`data.js`) si besoin.
- **Rendement actionnarial** : calculé comme dividende + (cash consacré aux rachats d'actions
  TTM / capitalisation). Peut être imprécis si le champ `commonStockRepurchasedTTM` est absent
  pour un titre donné.
- **Devises** : les montants sont affichés dans la devise renvoyée par l'API, sans conversion.
  Compare les scores entre pays, pas les prix ou capitalisations bruts.

## Pistes d'évolution

- Ajouter d'autres indices sources (Russell 2000 pour du small-cap US, plus proche de l'univers
  "All Stocks" original du livre que le S&P 500 qui est plutôt "Market Leaders").
- Ajouter un mode "watchlist" qui sauvegarde des tickers suivis dans le temps.
- Ajouter la comparaison multi-stratégies (Venn des tickers en commun entre 2 stratégies).
- Passer les poids de chaque facteur en paramètres réglables (actuellement poids égaux,
  fidèle au livre).

