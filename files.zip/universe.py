"""
Récupère l'univers réel des titres par pays via le screener Yahoo Finance
(région + capitalisation minimum), plutôt que par scraping de tableaux
Wikipedia — voir la note en tête de config.py pour le pourquoi.
"""
import time

# Utilise le magasin de certificats du système d'exploitation plutôt que la
# liste isolée fournie par `certifi`. Nécessaire sur les PC où un antivirus
# (Kaspersky, ESET, Avast...) inspecte le trafic HTTPS avec son propre
# certificat : Windows lui fait confiance, mais les libs Python seules non —
# d'où des erreurs "self-signed certificate in certificate chain" sans ce patch.
import truststore
truststore.inject_into_ssl()

import yfinance as yf
from yfinance import EquityQuery

from config import REGION_MAP, MAX_UNIVERSE_PER_COUNTRY


def fetch_country_universe(country_code, mcap_floor, max_results=MAX_UNIVERSE_PER_COUNTRY):
    """Interroge le screener Yahoo Finance pour TOUS les titres d'un pays
    dont la capitalisation dépasse `mcap_floor`, avec pagination (250 max
    par appel côté Yahoo). Retourne une liste de dicts
    {symbol, name, sector, country} — les tickers sont déjà au format Yahoo
    natif (ex. "MC.PA"), aucune supposition de suffixe à faire."""
    region = REGION_MAP.get(country_code)
    if not region:
        raise ValueError(f"Pas de code région Yahoo configuré pour {country_code}")

    query = EquityQuery("and", [
        EquityQuery("eq", ["region", region]),
        EquityQuery("gte", ["intradaymarketcap", mcap_floor]),
    ])

    out = []
    seen = set()
    offset = 0
    size = 250
    total = None

    while len(out) < max_results:
        resp = yf.screen(query, offset=offset, size=size, sortField="intradaymarketcap", sortAsc=False)
        quotes = resp.get("quotes", [])
        if total is None:
            total = resp.get("total", len(quotes))
        if not quotes:
            break

        for q in quotes:
            symbol = q.get("symbol")
            if not symbol or symbol in seen:
                continue
            seen.add(symbol)
            out.append({
                "symbol": symbol,
                "name": q.get("shortName") or q.get("longName") or symbol,
                "sector": q.get("sector") or "—",
                "country": country_code,
            })

        offset += size
        if offset >= total:
            break
        time.sleep(0.5)  # pause polie entre chaque page de résultats

    return out
