"""
Configuration du scraper — univers via le screener Yahoo Finance.

v2 : on a abandonné le scraping de tableaux Wikipedia (couverture inégale
selon les pays — indices moyens/petits souvent sans tableau exploitable)
au profit du VRAI screener Yahoo Finance, exposé par yfinance (`yf.screen`).
Interroger par région + capitalisation minimum donne un univers "All Stocks"
fidèle à la méthodologie du livre, plutôt qu'un indice figé limité aux blue
chips — et les tickers renvoyés sont déjà dans le bon format Yahoo, aucune
supposition de suffixe (.PA, .DE...) à faire.
"""

# code pays (utilisé partout ailleurs dans l'appli) -> code région Yahoo
# (confirmé 'us' et 'fr' en conditions réelles ; les autres suivent la même
# convention ISO-2 minuscule standard chez Yahoo — à confirmer à l'usage,
# un échec isolé n'empêche pas les autres pays de fonctionner)
REGION_MAP = {
    # Amérique du Nord
    "US": "us",
    "CA": "ca",
    # Europe
    "GB": "gb",
    "FR": "fr",
    "DE": "de",
    "CH": "ch",
    "NL": "nl",
    "ES": "es",
    "IT": "it",
    "BE": "be",
    "SE": "se",
    "DK": "dk",
    "NO": "no",
    "FI": "fi",
    "PT": "pt",
    "AT": "at",
    "IE": "ie",
    # Asie-Pacifique
    "JP": "jp",
    "AU": "au",
    "HK": "hk",
    "SG": "sg",
    "KR": "kr",
}

# Capitalisation minimum par défaut si non précisée en ligne de commande.
# 200 M$ = seuil "All Stocks" du livre (inflation ajustée, approximé ici).
DEFAULT_MCAP_FLOOR = 200_000_000

# Garde-fou : nombre max de titres récupérés par pays en une passe d'univers
# (Yahoo pagine par 250 max ; ce plafond évite qu'un pays énorme comme les
# USA ne ramène des milliers de microcaps si le seuil de cap est trop bas).
MAX_UNIVERSE_PER_COUNTRY = 1500

DB_PATH = "screener.db"
SNAPSHOT_PATH = "data-snapshot.json"  # à ajuster si scraper/ est un sous-dossier du site (ex. "../data-snapshot.json")

# Poli envers Yahoo : pause entre chaque titre (secondes), +/- un peu de hasard
REQUEST_DELAY_MIN = 0.6
REQUEST_DELAY_MAX = 1.4

DEFAULT_MAX_AGE_DAYS = 7  # au-delà, un titre est considéré "à rafraîchir"
