"""
Couche SQLite — stocke l'univers (composition des indices) et les
fondamentaux par titre, avec horodatage pour savoir ce qui doit être
rafraîchi.
"""
import sqlite3
import json
import time
from contextlib import contextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS universe (
    symbol TEXT PRIMARY KEY,
    name TEXT,
    country TEXT,
    sector TEXT,
    fetched_at REAL
);

CREATE TABLE IF NOT EXISTS fundamentals (
    symbol TEXT PRIMARY KEY,
    price REAL,
    mcap REAL,
    pb REAL,
    pe REAL,
    ps REAL,
    pcf REAL,
    ebitda_yield REAL,
    div_yield REAL,
    buyback_yield REAL,
    mom3 REAL,
    mom6 REAL,
    eps_growth REAL,
    fetched_at REAL,
    error TEXT
);
"""


@contextmanager
def connect(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript(SCHEMA)
        yield conn
        conn.commit()
    finally:
        conn.close()


def upsert_universe(conn, symbol, name, country, sector):
    conn.execute(
        """INSERT INTO universe (symbol, name, country, sector, fetched_at)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(symbol) DO UPDATE SET
             name=excluded.name, country=excluded.country,
             sector=excluded.sector, fetched_at=excluded.fetched_at""",
        (symbol, name, country, sector, time.time()),
    )


def upsert_fundamentals(conn, symbol, data, error=None):
    conn.execute(
        """INSERT INTO fundamentals
           (symbol, price, mcap, pb, pe, ps, pcf, ebitda_yield, div_yield,
            buyback_yield, mom3, mom6, eps_growth, fetched_at, error)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(symbol) DO UPDATE SET
             price=excluded.price, mcap=excluded.mcap, pb=excluded.pb,
             pe=excluded.pe, ps=excluded.ps, pcf=excluded.pcf,
             ebitda_yield=excluded.ebitda_yield, div_yield=excluded.div_yield,
             buyback_yield=excluded.buyback_yield, mom3=excluded.mom3,
             mom6=excluded.mom6, eps_growth=excluded.eps_growth,
             fetched_at=excluded.fetched_at, error=excluded.error""",
        (
            symbol,
            data.get("price"), data.get("mcap"), data.get("pb"), data.get("pe"),
            data.get("ps"), data.get("pcf"), data.get("ebitda_yield"),
            data.get("div_yield"), data.get("buyback_yield"), data.get("mom3"),
            data.get("mom6"), data.get("eps_growth"), time.time(), error,
        ),
    )


def get_universe(conn, countries=None):
    if countries:
        placeholders = ",".join("?" * len(countries))
        rows = conn.execute(
            f"SELECT * FROM universe WHERE country IN ({placeholders})", countries
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM universe").fetchall()
    return [dict(r) for r in rows]


def get_stale_symbols(conn, symbols, max_age_days):
    """Retourne le sous-ensemble de `symbols` absent de la table fundamentals
    ou dont la dernière récupération date de plus de `max_age_days`, en
    ignorant les erreurs (on retente toujours les échecs précédents)."""
    cutoff = time.time() - max_age_days * 86400
    fresh = set()
    rows = conn.execute(
        "SELECT symbol, fetched_at, error FROM fundamentals"
    ).fetchall()
    for r in rows:
        if r["error"] is None and r["fetched_at"] and r["fetched_at"] >= cutoff:
            fresh.add(r["symbol"])
    return [s for s in symbols if s not in fresh]


def get_all_fundamentals(conn):
    rows = conn.execute(
        """SELECT u.symbol, u.name, u.country, u.sector,
                  f.price, f.mcap, f.pb, f.pe, f.ps, f.pcf, f.ebitda_yield,
                  f.div_yield, f.buyback_yield, f.mom3, f.mom6, f.eps_growth,
                  f.fetched_at, f.error
           FROM universe u
           LEFT JOIN fundamentals f ON f.symbol = u.symbol"""
    ).fetchall()
    return [dict(r) for r in rows]
